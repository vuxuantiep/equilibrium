<?php
/**
 * Der Einstiegspunkt für das WordPress-Theme.
 * Da dies eine React-App ist, laden wir einfach die index.html.
 */
include( get_template_directory() . '/index.html' );
?>