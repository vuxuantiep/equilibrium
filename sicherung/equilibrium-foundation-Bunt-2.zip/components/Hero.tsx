
import React from 'react';
import { ArrowRight, Heart, Sparkles, Code, Globe, UserCheck, TreeDeciduous } from 'lucide-react';

const albumImages = [
  {
    url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=800&auto=format&fit=crop", // Children help
    label: "Globale Hilfe",
    icon: <Heart size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=800&auto=format&fit=crop", // Education
    label: "IT-Akademie",
    icon: <Code size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=800&auto=format&fit=crop", // Nature
    label: "Nachhaltigkeit",
    icon: <TreeDeciduous size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800&auto=format&fit=crop", // Team
    label: "Unser Team",
    icon: <UserCheck size={16} />
  }
];

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center pt-32 pb-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 w-full relative z-10">
        <div className="grid lg:grid-cols-12 gap-16 items-center">
          
          <div className="lg:col-span-7">
            <div className="inline-flex items-center space-x-3 bg-white/40 border border-[#f37021]/20 px-4 py-2 rounded-full mb-8 backdrop-blur-xl">
              <Heart size={16} className="text-[#f37021] fill-[#f37021]" />
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-[#1a1412]">Equilibrium Foundation</span>
            </div>
            
            <h1 className="text-4xl md:text-[4.2rem] font-black leading-[1.05] tracking-tighter mb-8 text-[#1a1412]">
              Technologie & Herz <br />
              <span className="serif-italic text-[#f37021] font-normal italic">für eine faire</span> <br />
              Zukunft weltweit.
            </h1>
            
            <p className="text-xl md:text-2xl text-stone-600 mb-12 leading-relaxed font-medium max-w-xl">
              Wir begleiten Gehörlose und Autisten in den IT-Arbeitsmarkt und fördern nachhaltige Projekte für Kinder und Umwelt im globalen Süden.
            </p>

            <div className="flex flex-col sm:flex-row gap-6">
              <button className="bg-[#f37021] hover:bg-[#ff8a45] text-white px-10 py-5 rounded-2xl font-black text-xl transition-all shadow-2xl shadow-orange-950/20 active:scale-95 flex items-center justify-center space-x-3 group">
                <span>Jetzt unterstützen</span>
                <ArrowRight size={22} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="bg-white/50 border border-stone-200 hover:bg-white text-[#1a1412] px-10 py-5 rounded-2xl font-bold text-xl transition-all backdrop-blur-md flex items-center justify-center">
                Wirkung ansehen
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            {/* Fotoalbum Grid */}
            <div className="grid grid-cols-2 gap-4 h-[500px] md:h-[600px]">
              {albumImages.map((img, i) => (
                <div key={i} className={`rounded-[2.5rem] overflow-hidden border-4 border-white shadow-2xl group relative ${i === 0 ? 'row-span-2' : ''}`}>
                  <img src={img.url} alt={img.label} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60"></div>
                  <div className="absolute bottom-6 left-6 flex items-center space-x-2 text-white">
                    <div className="bg-[#f37021] p-1.5 rounded-lg shadow-lg">
                      {img.icon}
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest">{img.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};