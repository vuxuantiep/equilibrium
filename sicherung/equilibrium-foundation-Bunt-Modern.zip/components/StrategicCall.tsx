
import React from 'react';
import { Mail, ShieldCheck, FileText, Heart, Sparkles } from 'lucide-react';

export const StrategicCall: React.FC = () => {
  return (
    <section className="py-32 bg-[#2a2624]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#332e2c] rounded-[70px] p-12 md:p-24 relative overflow-hidden shadow-3xl border border-white/5">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-500/5 rounded-full blur-[120px] -mr-60 -mt-60"></div>
          
          <div className="relative z-10 grid lg:grid-cols-2 gap-24 items-center">
            <div>
              <div className="inline-flex items-center space-x-3 text-[#0078d4] font-bold uppercase tracking-widest text-[11px] mb-10 bg-blue-500/10 px-6 py-2 rounded-full">
                <ShieldCheck size={18} />
                <span>Stiftungspartnerschaft</span>
              </div>
              <h3 className="text-6xl md:text-8xl font-extrabold text-white leading-[0.85] tracking-tighter mb-12">
                Fördere den <br /> <span className="serif-italic text-[#0078d4] font-normal italic">Fortschritt.</span>
              </h3>
              <p className="text-2xl text-stone-400 mb-16 leading-relaxed font-medium">
                Wir laden Stiftungen und Impact-Investoren ein, Teil unserer globalen Skalierung zu werden. Fordere jetzt unser Dossier an.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-6">
                <a href="mailto:info@equilibrium.foundation" className="bg-[#0078d4] hover:bg-[#005a9e] text-white px-12 py-6 rounded-2xl font-black text-xl transition-all flex items-center justify-center space-x-4 shadow-2xl shadow-blue-500/20 active:scale-95">
                  <Mail size={24} />
                  <span>Dialog starten</span>
                </a>
                <button className="bg-white/5 border-2 border-white/10 text-white px-12 py-6 rounded-2xl font-bold text-xl hover:bg-white/10 transition-all flex items-center justify-center space-x-4 backdrop-blur-md">
                  <FileText size={24} />
                  <span>Impact Dossier</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-8">
              {[
                { icon: <Heart className="text-red-500" size={32} />, bg: "bg-red-500/10", label: "Anerkannt Gemeinnützig" },
                { icon: <ShieldCheck className="text-blue-500" size={32} />, bg: "bg-blue-500/10", label: "Geprüfte Transparenz" },
                { icon: <FileText className="text-orange-500" size={32} />, bg: "bg-orange-500/10", label: "Auditierte Berichte" },
                { icon: <Sparkles className="text-green-500" size={32} />, bg: "bg-green-500/10", label: "Skalierbare Wirkung" }
              ].map((badge, i) => (
                <div key={i} className="bg-[#2a2624] border border-white/5 p-10 rounded-[40px] text-center flex flex-col items-center hover:bg-white/5 hover:-translate-y-2 transition-all duration-500 shadow-xl">
                  <div className={`${badge.bg} p-6 rounded-3xl mb-6`}>{badge.icon}</div>
                  <div className="text-white font-black text-sm tracking-tight uppercase tracking-widest leading-tight">{badge.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
