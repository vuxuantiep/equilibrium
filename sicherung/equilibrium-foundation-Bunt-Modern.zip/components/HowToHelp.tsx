
import React from 'react';
import { Wallet, Code2, HeartHandshake, Heart } from 'lucide-react';

export const HowToHelp: React.FC = () => {
  const options = [
    {
      title: "Finanzielle Unterstützung",
      description: "Jeder Beitrag hilft uns, Lehrmaterialien und Hardware für unsere Standorte bereitzustellen.",
      button: "Jetzt Spenden",
      icon: <Wallet size={40} className="text-[#4a5d23]" />,
      btnColor: "bg-[#4a5d23] hover:bg-[#3d4d1d]"
    },
    {
      title: "IT-Engagement",
      description: "Werden Sie Mentor oder unterstützen Sie uns bei der Entwicklung unserer Inklusions-Software.",
      button: "Mitmachen",
      icon: <Code2 size={40} className="text-[#c05a11]" />,
      btnColor: "bg-[#c05a11] hover:bg-[#a04a0e]"
    },
    {
      title: "Für Organisationen",
      description: "Bieten Sie Praktika an oder integrieren Sie unsere Absolventen in Ihre Teams.",
      button: "Kooperieren",
      icon: <HeartHandshake size={40} className="text-[#2a1f18]" />,
      btnColor: "bg-[#2a1f18] hover:bg-[#1a1410]"
    }
  ];

  return (
    <section id="engagement" className="py-24 bg-[#fcfaf7] text-stone-800 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <div className="bg-white p-4 rounded-full inline-block shadow-md mb-6 border border-stone-100">
            <Heart className="text-[#c05a11] fill-[#c05a11]" size={40} />
          </div>
          <h2 className="text-[#4a5d23] font-black uppercase tracking-widest text-sm mb-4">Unterstützung</h2>
          <h3 className="text-4xl md:text-5xl font-black mb-6 text-[#2a1f18]">Werden Sie Teil der <span className="text-[#c05a11]">Gemeinschaft</span></h3>
          <p className="text-xl text-stone-600 max-w-2xl mx-auto">
            Ihre Hilfe kommt dort an, wo sie am dringendsten benötigt wird: Direkt bei den Menschen.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {options.map((opt, i) => (
            <div key={i} className="bg-white border border-stone-200 p-12 rounded-xl hover:shadow-xl transition-all flex flex-col h-full">
              <div className="bg-[#fcfaf7] p-5 rounded-lg inline-block mb-8 shadow-inner">
                {opt.icon}
              </div>
              <h4 className="text-2xl font-bold mb-4 text-[#2a1f18]">{opt.title}</h4>
              <p className="text-stone-600 leading-relaxed mb-10 flex-grow">
                {opt.description}
              </p>
              <button className={`w-full ${opt.btnColor} text-white font-black py-4 rounded-lg transition-all shadow-md active:scale-95`}>
                {opt.button}
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
