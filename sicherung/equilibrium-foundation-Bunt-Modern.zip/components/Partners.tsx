
import React from 'react';

export const Partners: React.FC = () => {
  const partners = [
    { name: "FC St. Pauli Kiez Helden", color: "grayscale brightness-0 opacity-50" },
    { name: "Bingo! Umweltlotterie", color: "grayscale brightness-0 opacity-50" },
    { name: "NUE - Norddeutsche Umweltstiftung", color: "grayscale brightness-0 opacity-50" },
    { name: "Initiative Transparente Zivilgesellschaft", color: "grayscale brightness-0 opacity-50" }
  ];

  return (
    <section className="bg-white py-12 border-b border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap justify-center items-center gap-12 md:gap-24 opacity-60 grayscale hover:grayscale-0 transition-all duration-700">
          {/* Hier symbolische Platzhalter für die Logos aus den Fotos */}
          <div className="font-black text-stone-400 text-sm tracking-widest uppercase">Kiez Helden</div>
          <div className="font-black text-stone-400 text-sm tracking-widest uppercase">Bingo!</div>
          <div className="font-black text-stone-400 text-sm tracking-widest uppercase">NUE</div>
          <div className="font-black text-stone-400 text-[10px] max-w-[100px] leading-tight">Transparente Zivilgesellschaft</div>
        </div>
      </div>
    </section>
  );
};
