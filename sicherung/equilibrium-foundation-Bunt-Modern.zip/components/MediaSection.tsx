
import React from 'react';
import { PlayCircle, Video, Camera } from 'lucide-react';

export const MediaSection: React.FC = () => {
  const videos = [
    {
      title: "Ausbildung in Guatemala 2024",
      duration: "4:20",
      thumb: "https://images.unsplash.com/photo-1518107616385-ad30833edec1?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "Unsere KI im Einsatz",
      duration: "3:15",
      thumb: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=800&auto=format&fit=crop"
    }
  ];

  return (
    <section className="py-24 bg-[#fcfaf7]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center space-x-2 text-[#4a5d23] font-black uppercase tracking-widest text-sm mb-4">
            <Camera size={20} />
            <span>Mediathek</span>
          </div>
          <h3 className="text-4xl font-black text-[#2a1f18] mb-6">Wirkung in Bildern</h3>
          <p className="text-xl text-stone-600 max-w-2xl mx-auto font-medium">
            Erleben Sie die Fortschritte unserer Teams und die Atmosphäre vor Ort in Guatemala.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-14">
          {videos.map((vid, i) => (
            <div key={i} className="group cursor-pointer">
              <div className="relative aspect-video rounded-xl overflow-hidden shadow-lg mb-8 group-hover:shadow-2xl transition-all border-4 border-white">
                <img 
                  src={vid.thumb} 
                  alt={vid.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000"
                />
                <div className="absolute inset-0 bg-[#2a1f18]/20 group-hover:bg-transparent transition-colors flex items-center justify-center">
                  <PlayCircle size={72} className="text-white group-hover:text-[#c05a11] transition-colors drop-shadow-lg" />
                </div>
                <div className="absolute bottom-6 right-6 bg-white/90 backdrop-blur-md text-[#2a1f18] px-4 py-1.5 rounded-lg text-sm font-black shadow-md border border-stone-100">
                  {vid.duration}
                </div>
              </div>
              <h4 className="text-2xl font-black text-[#2a1f18] group-hover:text-[#4a5d23] transition-colors px-4">
                {vid.title}
              </h4>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
