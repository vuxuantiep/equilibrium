
import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronRight, ChevronLeft, Sparkles } from 'lucide-react';

const slides = [
  {
    image: "https://images.unsplash.com/photo-1573164713988-8665fc963095?q=80&w=1600&auto=format&fit=crop",
    title: "Digitale Freiheit",
    subtitle: "für alle.",
    accent: "text-[#0078d4]",
    desc: "Wir nutzen Software & KI, um Gehörlosen und Autisten den Weg in den Arbeitsmarkt zu ebnen – weltweit und nachhaltig."
  },
  {
    image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=1600&auto=format&fit=crop",
    title: "Bildung ohne",
    subtitle: "Grenzen.",
    accent: "text-[#8bc53f]",
    desc: "Unsere IT-Akademien in Guatemala, Mongolei und Afrika schaffen echte berufliche Perspektiven für Minderheiten."
  },
  {
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1600&auto=format&fit=crop",
    title: "KI-Lösungen",
    subtitle: "gemeinsam.",
    accent: "text-[#f37021]",
    desc: "Wir entwickeln eigene Open-Source Tools, die Sprachbarrieren am Arbeitsplatz durch intelligente KI eliminieren."
  }
];

export const Hero: React.FC = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % slides.length);
  const prev = () => setCurrent((prev) => (prev - 1 + slides.length) % slides.length);

  return (
    <section className="relative h-[100vh] w-full flex items-center overflow-hidden bg-[#2a2624]">
      {/* Slideshow Background */}
      {slides.map((slide, idx) => (
        <div 
          key={idx}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${idx === current ? 'opacity-40' : 'opacity-0'}`}
        >
          <img 
            src={slide.image} 
            alt={slide.title} 
            className="w-full h-full object-cover scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#2a2624] via-[#2a2624]/60 to-transparent"></div>
        </div>
      ))}
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="max-w-4xl">
          <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-full mb-10 backdrop-blur-md">
            <Sparkles size={16} className="text-[#0078d4]" />
            <span className="text-white text-[11px] font-bold uppercase tracking-widest">Technologie für den Wandel</span>
          </div>
          
          <div className="min-h-[320px]">
            <h1 className="text-6xl md:text-9xl font-extrabold text-white leading-[0.85] tracking-tighter mb-10 animate-in slide-in-from-left duration-700">
              {slides[current].title} <br />
              <span className={`serif-italic ${slides[current].accent} font-normal italic`}>{slides[current].subtitle}</span>
            </h1>
            
            <p className="text-xl md:text-3xl text-stone-300 mb-14 leading-relaxed max-w-2xl text-balance font-medium animate-in slide-in-from-left duration-1000 delay-100">
              {slides[current].desc}
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6">
            <button className="bg-[#0078d4] hover:bg-[#005a9e] text-white px-12 py-6 rounded-2xl font-black text-xl transition-all shadow-2xl shadow-blue-500/30 active:scale-95 flex items-center justify-center space-x-3 group">
              <span>Projekt fördern</span>
              <ArrowRight size={24} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="bg-white/5 border-2 border-white/10 hover:border-white/30 text-white px-12 py-6 rounded-2xl font-bold text-xl transition-all flex items-center justify-center backdrop-blur-sm">
              Mitmachen
            </button>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-16 right-16 flex items-center space-x-6 z-20">
        <button onClick={prev} className="p-4 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 text-white transition-all backdrop-blur-md active:scale-90">
          <ChevronLeft size={24} />
        </button>
        <div className="flex space-x-3">
          {slides.map((_, idx) => (
            <button 
              key={idx}
              onClick={() => setCurrent(idx)}
              className={`h-2.5 rounded-full transition-all duration-500 ${idx === current ? 'w-16 bg-[#0078d4] shadow-[0_0_15px_rgba(0,120,212,0.8)]' : 'w-2.5 bg-white/20 hover:bg-white/40'}`}
            />
          ))}
        </div>
        <button onClick={next} className="p-4 bg-white/5 hover:bg-white/10 rounded-full border border-white/10 text-white transition-all backdrop-blur-md active:scale-90">
          <ChevronRight size={24} />
        </button>
      </div>
    </section>
  );
};
