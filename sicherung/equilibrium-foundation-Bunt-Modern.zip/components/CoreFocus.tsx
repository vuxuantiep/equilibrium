
import React from 'react';
import { Code2, Brain, Globe2, ArrowRight } from 'lucide-react';

export const CoreFocus: React.FC = () => {
  const focuses = [
    {
      title: "Software Akademie",
      desc: "IT-Ausbildung für Gehörlose & Autisten in Guatemala, Indonesien und der Mongolei.",
      icon: <Code2 className="text-[#0078d4]" size={36} />,
      color: "bg-blue-500/10",
      accent: "border-[#0078d4]/30",
      glow: "hover:shadow-blue-500/10"
    },
    {
      title: "KI-Barrierefreiheit",
      desc: "Entwicklung eigener KI-Software zur Überwindung von Sprachbarrieren am Arbeitsplatz.",
      icon: <Brain className="text-[#8bc53f]" size={36} />,
      color: "bg-green-500/10",
      accent: "border-[#8bc53f]/30",
      glow: "hover:shadow-green-500/10"
    },
    {
      title: "Inklusions-Netzwerk",
      desc: "Wir vernetzen Firmen mit unseren Absolventen, um nachhaltige Jobs zu sichern.",
      icon: <Globe2 className="text-[#f37021]" size={36} />,
      color: "bg-orange-500/10",
      accent: "border-[#f37021]/30",
      glow: "hover:shadow-orange-500/10"
    }
  ];

  return (
    <section id="projekte" className="py-32 bg-[#2a2624]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row justify-between items-end mb-24 gap-12">
          <div className="max-w-2xl">
            <h2 className="text-[#0078d4] font-bold uppercase tracking-[0.4em] text-[11px] mb-6 flex items-center">
              <span className="w-12 h-[1px] bg-[#0078d4] mr-4"></span>
              Unser Kernprojekt
            </h2>
            <h3 className="text-5xl md:text-7xl font-extrabold text-white leading-none tracking-tighter">
              Brücken bauen <br /> <span className="serif-italic text-[#0078d4] font-normal italic">durch Code.</span>
            </h3>
          </div>
          <p className="text-2xl text-stone-400 max-w-sm leading-relaxed font-medium">
            Wir befähigen Menschen mit Behinderungen, ihre Zukunft durch Code selbst zu gestalten.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {focuses.map((f, i) => (
            <div key={i} className={`group p-12 rounded-[50px] border-2 ${f.accent} bg-[#332e2c] transition-all duration-500 hover:-translate-y-4 shadow-2xl ${f.glow}`}>
              <div className={`w-24 h-24 ${f.color} rounded-[30px] flex items-center justify-center mb-12 group-hover:scale-110 transition-transform shadow-inner`}>
                {f.icon}
              </div>
              <h4 className="text-3xl font-extrabold text-white mb-8 tracking-tight">{f.title}</h4>
              <p className="text-stone-400 leading-relaxed text-lg mb-12 font-medium">
                {f.desc}
              </p>
              <button className="flex items-center space-x-3 text-stone-300 font-black text-lg hover:text-[#0078d4] transition-colors group-hover:translate-x-2">
                <span>Details ansehen</span>
                <ArrowRight size={24} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
