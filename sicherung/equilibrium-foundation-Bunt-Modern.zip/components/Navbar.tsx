
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-[#2a2624]/90 backdrop-blur-xl border-b border-white/5 py-2' : 'bg-transparent py-4'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-3 group">
            <div className="relative w-12 h-12 flex items-center justify-center bg-white rounded-xl p-1.5 overflow-hidden group-hover:scale-105 transition-transform duration-300 shadow-lg shadow-white/5">
              <img 
                src="https://equilibrium.foundation/home/wp-content/uploads/2021/03/Logo_Equilibrium_Foundation.png" 
                alt="Equilibrium Logo" 
                className="w-full h-full object-contain"
              />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black leading-none tracking-tighter text-white">
                Equilibrium
              </span>
              <span className="text-[11px] font-bold uppercase tracking-[0.4em] text-stone-400 group-hover:text-[#0078d4] transition-colors">
                Foundation
              </span>
            </div>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            {['Projekte', 'Mission', 'Team', 'Kontakt'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`} 
                className="text-sm font-bold uppercase tracking-widest text-stone-300 hover:text-[#0078d4] transition-all relative group/item"
              >
                {item}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-[#0078d4] transition-all group-hover/item:w-full shadow-[0_0_8px_rgba(0,120,212,0.8)]"></span>
              </a>
            ))}
            <button className="bg-[#0078d4] hover:bg-[#005a9e] text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-blue-500/20 active:scale-95">
              Jetzt Fördern
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-white">
              {isOpen ? <X size={32} /> : <Menu size={32} />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden bg-[#2a2624] absolute top-full left-0 right-0 shadow-2xl border-t border-white/5 animate-in slide-in-from-top duration-300">
          <div className="px-4 py-8 space-y-6">
            {['Projekte', 'Mission', 'Team', 'Kontakt'].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`} 
                className="block text-xl font-black text-white uppercase tracking-widest"
                onClick={() => setIsOpen(false)}
              >
                {item}
              </a>
            ))}
            <button className="w-full bg-[#0078d4] text-white py-5 rounded-2xl font-black text-lg">
              Jetzt Fördern
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};
