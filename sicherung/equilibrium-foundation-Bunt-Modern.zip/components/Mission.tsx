
import React from 'react';
import { Recycle, Scissors, Trophy } from 'lucide-react';

export const Mission: React.FC = () => {
  return (
    <section id="mission" className="py-32 bg-[#332e2c]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="relative">
            <div className="grid grid-cols-2 gap-6">
              <div className="relative rounded-[40px] overflow-hidden aspect-[4/5] mt-16 shadow-2xl border-4 border-[#2a2624]">
                <img src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=500&auto=format&fit=crop" className="w-full h-full object-cover" alt="Recycling" />
              </div>
              <div className="relative rounded-[40px] overflow-hidden aspect-[4/5] shadow-2xl border-4 border-[#2a2624]">
                <img src="https://images.unsplash.com/photo-1523240632013-da209f354a0b?q=80&w=500&auto=format&fit=crop" className="w-full h-full object-cover" alt="Education" />
              </div>
            </div>
            <div className="absolute -bottom-10 -right-10 bg-[#8bc53f] text-white p-10 rounded-[40px] shadow-3xl hidden md:block border-8 border-[#332e2c]">
              <div className="text-5xl font-black italic mb-1 tracking-tighter">Impact</div>
              <div className="text-[11px] font-bold opacity-90 uppercase tracking-[0.4em]">Weltweit garantiert</div>
            </div>
          </div>

          <div>
            <h2 className="text-[#8bc53f] font-bold uppercase tracking-[0.4em] text-[11px] mb-8 flex items-center">
              <span className="w-12 h-[1px] bg-[#8bc53f] mr-4"></span>
              Ganzheitlicher Ansatz
            </h2>
            <h3 className="text-5xl md:text-7xl font-extrabold text-white mb-10 leading-[0.9] tracking-tighter">
              Inklusion ist <br /> <span className="serif-italic text-[#f37021] font-normal italic">grenzenlos.</span>
            </h3>
            <p className="text-2xl text-stone-400 mb-16 leading-relaxed font-medium">
              Neben Technologie fördern wir Selbstständigkeit durch ökologische und soziale Projekte, um Gemeinschaften ganzheitlich zu stärken.
            </p>
            
            <ul className="space-y-10">
              {[
                { icon: <Recycle className="text-[#8bc53f]" size={32} />, bg: "bg-green-500/10", title: "Umwelt & Recycling", desc: "Upcycling von Ressourcen als Einkommensquelle für lokale Gemeinschaften." },
                { icon: <Scissors className="text-[#f37021]" size={32} />, bg: "bg-orange-500/10", title: "Handwerk & Design", desc: "Berufliche Bildung für Frauen zur wirtschaftlichen Unabhängigkeit." },
                { icon: <Trophy className="text-[#0078d4]" size={32} />, bg: "bg-blue-500/10", title: "Sport & Teamgeist", desc: "Integration durch gemeinsame Erlebnisse und sportliche Förderung." }
              ].map((item, i) => (
                <li key={i} className="flex space-x-8 group">
                  <div className={`${item.bg} p-6 rounded-3xl shadow-xl border border-white/5 h-fit group-hover:scale-110 transition-transform duration-500`}>
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-2xl text-white mb-2">{item.title}</h4>
                    <p className="text-stone-400 text-lg font-medium leading-relaxed">{item.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
