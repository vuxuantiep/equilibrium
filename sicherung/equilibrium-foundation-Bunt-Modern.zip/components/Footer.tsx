
import React from 'react';
import { Mail, MapPin, Twitter, Linkedin, Github } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#2a2624] text-stone-500 py-32 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-20 mb-24">
          <div className="md:col-span-5">
            <div className="flex items-center space-x-3 mb-10">
              <div className="bg-white p-1 rounded-xl shadow-lg">
                <img 
                  src="https://equilibrium.foundation/home/wp-content/uploads/2021/03/Logo_Equilibrium_Foundation.png" 
                  alt="Equilibrium Logo" 
                  className="h-10 w-auto"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-3xl font-black text-white leading-none tracking-tighter uppercase">Equilibrium</span>
                <span className="text-[11px] font-bold text-stone-500 uppercase tracking-[0.4em]">Foundation</span>
              </div>
            </div>
            <p className="text-xl leading-relaxed mb-12 font-medium max-w-md text-stone-400 opacity-80">
              Wir nutzen die Kraft der Technologie, um Barrieren abzubauen und Menschen mit Behinderung eine selbstbestimmte Zukunft im digitalen Zeitalter zu ermöglichen.
            </p>
            <div className="flex space-x-6">
              {[Twitter, Linkedin, Github].map((Icon, i) => (
                <a key={i} href="#" className="p-4 bg-white/5 border border-white/5 rounded-2xl text-stone-300 hover:text-[#0078d4] hover:bg-white/10 transition-all transform hover:-translate-y-2">
                  <Icon size={24} />
                </a>
              ))}
            </div>
          </div>
          
          <div className="md:col-span-3">
            <h5 className="text-white font-black text-xs mb-10 uppercase tracking-[0.3em]">Programm</h5>
            <ul className="space-y-6 font-bold text-lg">
              <li><a href="#" className="text-stone-400 hover:text-[#0078d4] transition-colors">Software Akademie</a></li>
              <li><a href="#" className="text-stone-400 hover:text-[#0078d4] transition-colors">KI-Forschung</a></li>
              <li><a href="#" className="text-stone-400 hover:text-[#0078d4] transition-colors">Job-Placement</a></li>
              <li><a href="#" className="text-stone-400 hover:text-[#0078d4] transition-colors">Partner-Netzwerk</a></li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <h5 className="text-white font-black text-xs mb-10 uppercase tracking-[0.3em]">Kontakt</h5>
            <div className="bg-[#332e2c] p-10 rounded-[40px] border border-white/5 space-y-10 shadow-2xl">
              <div className="flex items-start space-x-5 group">
                <div className="p-3 bg-blue-500/10 rounded-2xl group-hover:bg-blue-500 group-hover:text-white transition-colors">
                  <Mail size={24} className="text-[#0078d4] group-hover:text-current" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-stone-500 mb-1">Email uns</div>
                  <a href="mailto:info@equilibrium.foundation" className="font-bold text-xl text-white hover:text-[#0078d4] transition-colors">info@equilibrium.foundation</a>
                </div>
              </div>
              <div className="flex items-start space-x-5 group">
                <div className="p-3 bg-green-500/10 rounded-2xl group-hover:bg-green-500 group-hover:text-white transition-colors">
                  <MapPin size={24} className="text-[#8bc53f] group-hover:text-current" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-stone-500 mb-1">Standort</div>
                  <span className="font-bold text-xl text-stone-300">Hamburg, Deutschland</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-16 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex flex-wrap justify-center gap-16 opacity-40 grayscale group-hover:grayscale-0 transition-all">
             <span className="font-black text-[11px] uppercase tracking-[0.3em] text-white">FC St. Pauli</span>
             <span className="font-black text-[11px] uppercase tracking-[0.3em] text-white">Bingo! Lotto</span>
             <span className="font-black text-[11px] uppercase tracking-[0.3em] text-white">NUE Foundation</span>
          </div>
          <p className="text-[11px] font-bold text-stone-600 uppercase tracking-[0.3em]">
            &copy; {new Date().getFullYear()} Equilibrium Foundation gGmbH.
          </p>
        </div>
      </div>
    </footer>
  );
};
