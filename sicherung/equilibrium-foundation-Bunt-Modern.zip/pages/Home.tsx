
import React from 'react';
import { Hero } from '../components/Hero';
import { Partners } from '../components/Partners';
import { CoreFocus } from '../components/CoreFocus';
import { Mission } from '../components/Mission';
import { ImpactStats } from '../components/ImpactStats';
import { StrategicCall } from '../components/StrategicCall';
import { MediaSection } from '../components/MediaSection';

const Home: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-1000">
      <Hero />
      <Partners />
      <CoreFocus />
      <ImpactStats />
      <Mission />
      <MediaSection />
      <StrategicCall />
    </div>
  );
};

export default Home;
