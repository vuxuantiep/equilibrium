
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Heart } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Projekte', path: '#projekte' },
    { name: 'Spenden', path: '#engagement' },
    { name: 'Engagement', path: '#engagement' },
    { name: 'Über uns', path: '#mission' },
    { name: 'Kontakt', path: '#footer' }
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-700 ${isScrolled ? 'py-4' : 'py-8'}`}>
      <div className="max-w-7xl mx-auto px-6">
        <div className={`flex justify-between items-center bg-[#231b18]/80 backdrop-blur-xl border border-white/5 p-4 rounded-[2.5rem] transition-all shadow-2xl ${isScrolled ? 'scale-[0.98]' : 'scale-100'}`}>
          <Link to="/" className="flex items-center space-x-4 pl-4 group">
            <div className="w-12 h-12 bg-white rounded-2xl p-2 transition-transform group-hover:scale-110 shadow-lg">
              <img src="https://equilibrium.foundation/home/wp-content/uploads/2021/03/Logo_Equilibrium_Foundation.png" alt="Logo" className="w-full h-full object-contain" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-black tracking-tighter leading-none text-white">EQUILIBRIUM</span>
              <span className="text-[10px] font-bold tracking-[0.4em] text-[#f37021]">FOUNDATION</span>
            </div>
          </Link>

          <div className="hidden md:flex items-center space-x-10 pr-4">
            {menuItems.map((item) => (
              <a key={item.name} href={item.path} className="text-[11px] font-black uppercase tracking-[0.2em] text-stone-300 hover:text-[#f37021] transition-colors">
                {item.name}
              </a>
            ))}
            <button className="bg-[#f37021] hover:bg-[#ff8a45] text-white px-8 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-xl shadow-orange-950/20 active:scale-95 flex items-center space-x-2">
              <Heart size={14} fill="currentColor" />
              <span>Unterstützen</span>
            </button>
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 text-white">
            {isOpen ? <X size={32} /> : <Menu size={32} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden fixed inset-0 bg-[#1a1412] z-[110] p-10 flex flex-col justify-center items-center space-y-10 animate-in fade-in zoom-in duration-300">
           <button onClick={() => setIsOpen(false)} className="absolute top-10 right-10 text-white"><X size={48} /></button>
           {menuItems.map((item) => (
              <a key={item.name} href={item.path} onClick={() => setIsOpen(false)} className="text-4xl font-black text-white hover:text-[#f37021] transition-colors uppercase tracking-tighter">
                {item.name}
              </a>
            ))}
            <button className="w-full bg-[#f37021] text-white py-6 rounded-3xl font-black text-2xl mt-12">Jetzt unterstützen</button>
        </div>
      )}
    </nav>
  );
};