
import React from 'react';
import { Mail, MapPin, Twitter, Linkedin, Instagram, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer id="footer" className="bg-[#fdfaf7] text-stone-600 py-32 border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-20 mb-24">
          <div className="md:col-span-5">
            <div className="flex items-center space-x-3 mb-10">
              <div className="bg-white p-1 rounded-xl shadow-lg border border-stone-100">
                <img src="https://equilibrium.foundation/home/wp-content/uploads/2021/03/Logo_Equilibrium_Foundation.png" alt="Logo" className="h-10 w-auto" />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-black text-[#1a1412] leading-none tracking-tighter">EQUILIBRIUM</span>
                <span className="text-[10px] font-bold text-[#f37021] uppercase tracking-[0.4em]">Foundation</span>
              </div>
            </div>
            <p className="text-xl leading-relaxed mb-12 font-medium max-w-md text-stone-500">
              Inklusion durch Technologie, Hoffnung durch Gemeinschaft. Wir schaffen Wege für Menschen weltweit.
            </p>
            <div className="flex space-x-4">
              {[Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="p-4 bg-white border border-stone-200 rounded-2xl text-stone-400 hover:text-[#f37021] hover:border-[#f37021] transition-all shadow-sm">
                  <Icon size={24} />
                </a>
              ))}
            </div>
          </div>
          
          <div className="md:col-span-3">
            <h5 className="text-[#1a1412] font-black text-xs mb-10 uppercase tracking-[0.3em]">Kapitel</h5>
            <ul className="space-y-6 font-bold text-lg">
              <li><a href="#" className="hover:text-[#f37021] transition-colors">Bildung & IT</a></li>
              <li><a href="#" className="hover:text-[#f37021] transition-colors">Soziale Hilfe</a></li>
              <li><a href="#" className="hover:text-[#f37021] transition-colors">Nachhaltigkeit</a></li>
              <li><a href="#" className="hover:text-[#f37021] transition-colors">Transparenz</a></li>
            </ul>
          </div>

          <div className="md:col-span-4">
            <h5 className="text-[#1a1412] font-black text-xs mb-10 uppercase tracking-[0.3em]">Kontakt</h5>
            <div className="bg-white p-10 rounded-[3rem] border border-stone-200 space-y-10 shadow-xl">
              <div className="flex items-start space-x-5">
                <div className="bg-[#f37021]/10 p-3 rounded-xl">
                  <Mail size={24} className="text-[#f37021]" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1">Email</div>
                  <a href="mailto:info@equilibrium.foundation" className="font-bold text-xl text-[#1a1412]">info@equilibrium.foundation</a>
                </div>
              </div>
              <div className="flex items-start space-x-5">
                <div className="bg-[#4a5d23]/10 p-3 rounded-xl">
                  <MapPin size={24} className="text-[#4a5d23]" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-stone-400 mb-1">Hamburg</div>
                  <span className="font-bold text-xl text-[#1a1412]">Zentrale Deutschland</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-16 border-t border-stone-200 flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex items-center space-x-2 text-[11px] font-black uppercase tracking-[0.2em] text-stone-400">
             <Heart size={14} className="text-[#f37021]" />
             <span>Partners: Kiez Helden • Bingo! Umwelt • NUE</span>
          </div>
          <p className="text-[10px] font-bold text-stone-400 uppercase tracking-[0.3em]">
            &copy; {new Date().getFullYear()} Equilibrium Foundation gGmbH.
          </p>
        </div>
      </div>
    </footer>
  );
};