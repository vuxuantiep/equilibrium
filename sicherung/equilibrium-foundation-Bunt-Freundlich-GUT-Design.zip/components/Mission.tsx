
import React from 'react';
import { CheckCircle2, ShieldCheck, Heart } from 'lucide-react';

export const Mission: React.FC = () => {
  return (
    <section id="mission" className="py-32 bg-[#14110f] border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="relative">
            <div className="grid grid-cols-2 gap-6 relative z-10">
              <div className="rounded-[3rem] overflow-hidden aspect-[4/5] mt-16 shadow-2xl border border-white/5 transform hover:rotate-2 transition-transform duration-700">
                <img src="https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=500&auto=format&fit=crop" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" alt="Inklusion" />
              </div>
              <div className="rounded-[3rem] overflow-hidden aspect-[4/5] shadow-2xl border border-white/5 transform hover:-rotate-2 transition-transform duration-700">
                <img src="https://images.unsplash.com/photo-1518107616385-ad30833edec1?q=80&w=500&auto=format&fit=crop" className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000" alt="Erfolg" />
              </div>
            </div>
            {/* Absolute Badge */}
            <div className="absolute -bottom-10 -right-6 bg-[#27ae60] text-white p-10 rounded-[3rem] shadow-3xl hidden md:block border-8 border-[#14110f]">
              <div className="serif-italic text-5xl font-normal italic mb-1">100%</div>
              <div className="text-[10px] font-bold uppercase tracking-widest opacity-80">Transparenz</div>
            </div>
          </div>

          <div>
            <h2 className="serif-italic text-[#d46a4a] text-3xl mb-6 font-normal italic">Mission & Werte</h2>
            <h3 className="text-5xl md:text-7xl font-extrabold text-white mb-10 leading-[0.9] tracking-tighter">
              Wir glauben an <br /> <span className="text-[#27ae60]">Teilhabe.</span>
            </h3>
            <p className="text-2xl text-stone-400 mb-16 leading-relaxed font-medium">
              Wahre Inklusion bedeutet nicht nur die Beseitigung von Barrieren, sondern das aktive Schaffen von Möglichkeiten auf Augenhöhe.
            </p>
            
            <ul className="space-y-12">
              {[
                { icon: <ShieldCheck className="text-[#27ae60]" size={32} />, title: "Geprüfte Qualität", desc: "Unsere Bildungsprogramme sind nach internationalen IT-Standards zertifiziert." },
                { icon: <Heart className="text-[#d46a4a]" size={32} />, title: "Mensch im Mittelpunkt", desc: "Jedes Tool wird direkt mit der Community entwickelt." }
              ].map((item, i) => (
                <li key={i} className="flex space-x-8 group">
                  <div className="bg-white/5 p-5 rounded-2xl h-fit border border-white/10 group-hover:bg-[#27ae60]/10 transition-colors">
                    {item.icon}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-2xl text-white mb-2">{item.title}</h4>
                    <p className="text-stone-500 text-lg font-medium leading-relaxed">{item.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};
