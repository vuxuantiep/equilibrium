
import React from 'react';
import { GraduationCap, Cpu, Leaf, ArrowRight } from 'lucide-react';

export const MainProjects: React.FC = () => {
  const mainCards = [
    {
      title: "IT-Akademie",
      subtitle: "Bildung für Gehörlose & Autisten",
      desc: "Berufliche Ausbildung zu Software-Entwicklern, um echte wirtschaftliche Unabhängigkeit zu schaffen.",
      icon: <GraduationCap size={44} className="text-white" />,
      color: "bg-[#f37021]",
      img: "https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=600&auto=format&fit=crop"
    },
    {
      title: "KI-Lösungen",
      subtitle: "Software für Barrierefreiheit",
      desc: "Entwicklung von Tools, die Gebärdensprache übersetzen und reizarme Arbeitsumgebungen fördern.",
      icon: <Cpu size={44} className="text-white" />,
      color: "bg-[#00a1e1]",
      img: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=600&auto=format&fit=crop"
    },
    {
      title: "Sozialer Impact",
      subtitle: "Zukunft für Kinder weltweit",
      desc: "Bildung, Sport und Nachhaltigkeitsprojekte für benachteiligte Kinder in Afrika und Mittelamerika.",
      icon: <Leaf size={44} className="text-white" />,
      color: "bg-[#4a5d23]",
      img: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=600&auto=format&fit=crop"
    }
  ];

  return (
    <section id="projekte" className="py-32 bg-[#fdfaf7] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-24">
          <h2 className="serif-italic text-[#f37021] text-3xl mb-4 italic">Unser Engagement</h2>
          <h3 className="text-5xl md:text-6xl font-black tracking-tighter text-[#1a1412] leading-tight">
            Wir bauen Brücken in eine <span className="text-[#4a5d23]">bessere Welt.</span>
          </h3>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          {mainCards.map((card, i) => (
            <div key={i} className="group relative rounded-[3rem] overflow-hidden shadow-2xl hover:-translate-y-4 transition-all duration-700 bg-white">
              <div className="h-64 overflow-hidden relative">
                <img src={card.img} alt={card.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                <div className={`absolute -bottom-10 right-10 ${card.color} p-6 rounded-3xl shadow-xl z-10`}>
                  {card.icon}
                </div>
              </div>
              <div className="p-10 pt-14">
                <div className="text-stone-400 font-bold text-[10px] uppercase tracking-[0.3em] mb-4">{card.subtitle}</div>
                <h4 className="text-2xl font-black text-[#1a1412] mb-6 leading-tight group-hover:text-[#f37021] transition-colors">{card.title}</h4>
                <p className="text-stone-500 text-lg leading-relaxed mb-10 font-medium">
                  {card.desc}
                </p>
                <button className="flex items-center space-x-3 text-[#1a1412] font-black group-hover:text-[#f37021] transition-colors text-lg">
                  <span>Mehr erfahren</span>
                  <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};