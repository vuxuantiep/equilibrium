
import React from 'react';
import { ArrowRight, Heart, Sparkles, Code, Globe, UserCheck, TreeDeciduous } from 'lucide-react';

const albumImages = [
  {
    url: "https://images.unsplash.com/photo-1573164713988-8665fc963095?q=80&w=800&auto=format&fit=crop",
    label: "IT-Bildung",
    icon: <Code size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=800&auto=format&fit=crop",
    label: "Hilfe für Kinder",
    icon: <Heart size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1518604666860-9ed391f76460?q=80&w=800&auto=format&fit=crop",
    label: "Fußball Afrika",
    icon: <Globe size={16} />
  },
  {
    url: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=800&auto=format&fit=crop",
    label: "Nachhaltigkeit",
    icon: <TreeDeciduous size={16} />
  }
];

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center pt-24 pb-12 overflow-hidden bg-fixed-nature">
      {/* Decorative Warm Overlays */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#1a1412]/60 via-transparent to-[#fdfaf7] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-6 w-full relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6">
            <div className="inline-flex items-center space-x-3 bg-white/10 border border-white/20 px-4 py-2 rounded-full mb-8 backdrop-blur-xl">
              <Heart size={16} className="text-[#f37021] fill-[#f37021]" />
              <span className="text-[11px] font-bold uppercase tracking-[0.2em] text-white">Equilibrium Foundation</span>
            </div>
            
            <h1 className="text-5xl md:text-[4.5rem] font-black leading-[1.1] tracking-tighter mb-8 text-white">
              Technologie & Herz <br />
              <span className="serif-italic text-[#f37021] font-normal italic">für eine faire</span> <br />
              Zukunft weltweit.
            </h1>
            
            <p className="text-lg md:text-xl text-stone-200 mb-12 leading-relaxed font-medium max-w-xl">
              Wir begleiten Gehörlose und Autisten in den IT-Arbeitsmarkt und fördern nachhaltige Projekte für Kinder und Umwelt im globalen Süden.
            </p>

            <div className="flex flex-col sm:flex-row gap-5">
              <button className="bg-[#f37021] hover:bg-[#ff8a45] text-white px-8 py-4 rounded-2xl font-black text-lg transition-all shadow-2xl shadow-orange-950/40 active:scale-95 flex items-center justify-center space-x-3 group">
                <span>Jetzt fördern</span>
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="bg-white/10 border border-white/20 hover:border-white/40 text-white px-8 py-4 rounded-2xl font-bold text-lg transition-all backdrop-blur-md flex items-center justify-center">
                Mehr erfahren
              </button>
            </div>
          </div>

          <div className="lg:col-span-6">
            {/* Mosaic Photo Album Grid showing Foundation Projects */}
            <div className="grid grid-cols-2 gap-4 h-[500px]">
              {albumImages.map((img, i) => (
                <div key={i} className={`rounded-[2rem] overflow-hidden border-4 border-white/20 shadow-2xl group relative ${i === 0 ? 'row-span-2 h-full' : 'h-[242px]'}`}>
                  <img src={img.url} alt={img.label} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 flex items-center space-x-2 text-white">
                    <div className="bg-[#f37021] p-1.5 rounded-lg">{img.icon}</div>
                    <span className="text-[10px] font-bold uppercase tracking-widest">{img.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};