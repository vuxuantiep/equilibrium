
import React from 'react';
import { Hero } from '../components/Hero';
import { Mission } from '../components/Mission';
import { Projects } from '../components/Projects';
import { Gallery } from '../components/Gallery';
import { WhatWeDo } from '../components/WhatWeDo';
import { ImpactStats } from '../components/ImpactStats';
import { HowToHelp } from '../components/HowToHelp';
import { MediaSection } from '../components/MediaSection';
import { TeamSection } from '../components/TeamSection';
import { Heart, Trees } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="animate-in fade-in duration-700 bg-[#fcfaf7]">
      <Hero />
      <Mission />
      <WhatWeDo />
      <ImpactStats />
      <Projects />
      <Gallery />
      <TeamSection />
      <HowToHelp />
      <MediaSection />
      
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-gradient-to-br from-[#4a5d23] to-[#3d4d1d] rounded-2xl p-16 md:p-24 text-center shadow-2xl relative overflow-hidden">
             {/* Decorative background icon */}
             <Trees size={300} className="absolute -bottom-20 -right-20 text-white/5 pointer-events-none" />
             
            <div className="inline-block p-4 bg-white/20 rounded-xl mb-8 backdrop-blur-sm">
              <Heart className="text-white fill-white" size={40} />
            </div>
            <h3 className="text-3xl md:text-6xl font-black text-white mb-8 leading-tight">
              Gemeinsam <br /> <span className="text-[#fcfaf7]">Zukunft</span> codieren.
            </h3>
            <p className="text-xl md:text-2xl text-stone-200 mb-12 max-w-3xl mx-auto font-medium">
              Sprechen Sie mit uns über eine strategische Partnerschaft. Gemeinsam geben wir Menschen im globalen Süden eine Stimme und eine Perspektive.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
              <button className="w-full sm:w-auto bg-white text-[#4a5d23] hover:bg-stone-100 px-12 py-6 rounded-lg font-black text-xl shadow-xl transition-all transform hover:scale-105 active:scale-95">
                Stiftungs-Dialog
              </button>
              <button className="w-full sm:w-auto bg-transparent border-2 border-white/40 text-white hover:bg-white/10 px-12 py-6 rounded-lg font-black text-xl transition-all">
                Kontakt aufnehmen
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
