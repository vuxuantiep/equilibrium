
import React from 'react';
import { Heart, ShieldCheck, Sparkles, Anchor } from 'lucide-react';

export const Mission: React.FC = () => {
  const principles = [
    {
      icon: <Heart className="text-[#c05a11]" size={32} />,
      title: "Empathie & Respekt",
      text: "Unsere Kernwerte leiten uns in der Begegnung mit Menschen auf Augenhöhe – unabhängig von ihrer Herkunft."
    },
    {
      icon: <ShieldCheck className="text-[#4a5d23]" size={32} />,
      title: "Ethik & Humanismus",
      text: "Wir handeln nach tiefen moralischen Prinzipien, um die Würde benachteiligter Gruppen weltweit zu schützen."
    },
    {
      icon: <Anchor className="text-[#4a5d23]" size={32} />,
      title: "Seit 2014 in Hamburg",
      text: "Gegründet in der Hansestadt, sind wir seit 2018 als gemeinnützige gGmbH für sozialen Impact registriert."
    }
  ];

  return (
    <section id="ueber-uns" className="py-24 bg-[#fcfaf7] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
             <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl z-10 relative border-8 border-white">
               <img 
                 src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=1000&auto=format&fit=crop" 
                 alt="Stärkung lokaler Gemeinschaften" 
                 className="w-full h-full object-cover"
               />
             </div>
             <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-[#4a5d23]/10 rounded-full blur-3xl"></div>
          </div>

          <div>
            <h2 className="text-[#4a5d23] font-black tracking-widest uppercase text-sm mb-4">Vision & Mission</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold text-[#2a1f18] mb-8 leading-tight">
              Gerechtigkeit im <span className="text-[#c05a11] italic">globalen Süden</span>.
            </h3>
            <p className="text-lg text-stone-600 leading-relaxed mb-10">
              Die Equilibrium Foundation stärkt benachteiligte Menschen, Multiplikatoren und NGOs in Asien, Afrika und Mittelamerika. Wir schaffen ein wirtschaftliches Gleichgewicht durch nachhaltige Projekte in den Bereichen <strong>Bildung, Kultur und Umwelt</strong>.
            </p>
            <div className="space-y-8">
              {principles.map((p, i) => (
                <div key={i} className="flex items-start space-x-5 group">
                  <div className="bg-white p-4 rounded-xl shrink-0 border border-stone-100 shadow-sm group-hover:shadow-md transition-all">
                    {p.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-[#2a1f18] text-xl mb-1">{p.title}</h4>
                    <p className="text-stone-600 leading-relaxed">{p.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
