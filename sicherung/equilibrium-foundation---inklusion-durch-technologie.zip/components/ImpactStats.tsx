
import React from 'react';

export const ImpactStats: React.FC = () => {
  const stats = [
    { label: "Durchgeführte Projekte", value: "12" },
    { label: "Menschen erreicht", value: "600+" },
    { label: "Engagierte Aktivisten", value: "12" },
    { label: "Kontinente", value: "3" }
  ];

  return (
    <section className="bg-[#4a5d23] py-24 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -mr-32 -mt-32"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 text-center">
          {stats.map((stat, i) => (
            <div key={i} className="text-white group">
              <div className="text-6xl md:text-7xl font-black mb-3 transition-transform group-hover:scale-110 duration-500">{stat.value}</div>
              <div className="text-[#c7d5a0] font-black uppercase tracking-widest text-sm md:text-base">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
