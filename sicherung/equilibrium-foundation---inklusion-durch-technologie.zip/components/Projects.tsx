
import React from 'react';
import { GraduationCap, Brain, Globe, ArrowUpRight } from 'lucide-react';

export const Projects: React.FC = () => {
  const projectList = [
    {
      title: "Zertifizierte Bildung",
      description: "Wir vergeben offizielle Zertifikate für unsere IT- und Gebärdensprache-Kurse, um den Zugang zum Arbeitsmarkt messbar zu machen.",
      tag: "Akademie",
      icon: <GraduationCap className="text-white" size={28} />,
      color: "bg-[#4a5d23]",
      accent: "text-[#4a5d23]",
      img: "https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "Visuelle Kommunikation",
      description: "Nutzung von Gebärdensprache-Postern und taktilen Lernmaterialien zur Förderung der Alphabetisierung benachteiligter Gruppen.",
      tag: "Kultur",
      icon: <Brain className="text-white" size={28} />,
      color: "bg-[#c05a11]",
      accent: "text-[#c05a11]",
      img: "https://images.unsplash.com/photo-1516321497487-e288fb19713f?q=80&w=800&auto=format&fit=crop"
    },
    {
      title: "Globale Gemeinschaften",
      description: "Von Dorf-Akademien in Afrika bis zu Bildungszentren in der Mongolei – wir fördern Inklusion im lokalen Kontext.",
      tag: "Umwelt",
      icon: <Globe className="text-white" size={28} />,
      color: "bg-[#3c2a1a]",
      accent: "text-[#3c2a1a]",
      img: "https://images.unsplash.com/photo-1523348830708-15d4a09cfac2?q=80&w=800&auto=format&fit=crop"
    }
  ];

  return (
    <section id="projekte" className="py-24 bg-white border-y border-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-[#4a5d23] font-black uppercase tracking-widest text-sm mb-4">Unsere Aktivitäten</h2>
          <h3 className="text-4xl md:text-5xl font-black text-[#2a1f18] mb-6">Hilfe, die <span className="text-[#c05a11]">Spuren</span> hinterlässt</h3>
          <p className="text-xl text-stone-600 max-w-2xl mx-auto font-medium">
            Entdecken Sie unsere interdisziplinäre Arbeit im globalen Süden, basierend auf Humanismus und ethischem Fortschritt.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-10">
          {projectList.map((project, idx) => (
            <div key={idx} className="group bg-[#fcfaf7] rounded-xl overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col h-full border border-stone-200">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={project.img} 
                  alt={project.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className={`absolute top-0 left-0 ${project.color} p-4 rounded-br-xl shadow-lg`}>
                  {project.icon}
                </div>
              </div>
              <div className="p-10 flex flex-col flex-grow">
                <span className={`text-xs font-black uppercase tracking-widest mb-4 ${project.accent}`}>{project.tag}</span>
                <h4 className="text-2xl font-bold text-[#2a1f18] mb-4">{project.title}</h4>
                <p className="text-stone-600 leading-relaxed mb-8 flex-grow">
                  {project.description}
                </p>
                <button className={`flex items-center space-x-2 ${project.accent} font-black group/btn border-b-2 border-transparent hover:border-current transition-all pb-1 w-fit`}>
                  <span>Details ansehen</span>
                  <ArrowUpRight size={18} className="group-hover/btn:translate-x-1" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
