
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Heart } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Projekte', path: '#projekte' },
    { name: 'Spenden', path: '#spenden' },
    { name: 'Engagement', path: '#engagement' },
    { name: 'Über uns', path: '#ueber-uns' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <div className={`p-2 rounded-lg bg-[#4a5d23] text-white shadow-md transition-all duration-300 transform group-hover:scale-105`}>
              <Heart size={24} fill="currentColor" />
            </div>
            <span className={`text-xl font-bold tracking-tight ${isScrolled ? 'text-[#2a1f18]' : 'text-white drop-shadow-md'}`}>
              Equilibrium <span className="text-[#c05a11]">Foundation</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.path} 
                className={`font-semibold transition-colors hover:text-[#4a5d23] ${isScrolled ? 'text-stone-700' : 'text-white'}`}
              >
                {link.name}
              </a>
            ))}
            <button className="bg-[#c05a11] hover:bg-[#a04a0e] text-white px-6 py-2.5 rounded-lg font-bold transition-all shadow-md active:scale-95">
              Jetzt Fördern
            </button>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className={`p-2 rounded-lg ${isScrolled ? 'text-stone-900' : 'text-white'}`}>
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};
