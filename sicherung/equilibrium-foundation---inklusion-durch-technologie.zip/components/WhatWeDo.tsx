
import React from 'react';
import { Layers, Briefcase, Users, Zap } from 'lucide-react';

export const WhatWeDo: React.FC = () => {
  const activities = [
    {
      title: "Kapazitätsaufbau",
      desc: "Wir stärken die individuellen und kollektiven Kompetenzen unserer lokalen Partner für langfristigen Erfolg.",
      icon: <Layers size={28} />
    },
    {
      title: "Projektmanagement",
      desc: "Effiziente Planung und Durchführung von Bildungs- und Umweltprojekten direkt vor Ort.",
      icon: <Briefcase size={28} />
    },
    {
      title: "Personalvermittlung",
      desc: "Wir bringen Talente und Organisationen zusammen, um lokale Autonomie und Beschäftigung zu fördern.",
      icon: <Users size={28} />
    },
    {
      title: "Ressourcenmobilisierung",
      desc: "Beschaffung von technischer Ausrüstung und Bildungsmaterialien für unsere Partner im globalen Süden.",
      icon: <Zap size={28} />
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-[#4a5d23] font-black uppercase tracking-widest text-sm mb-4">Unser Ansatz</h2>
          <h3 className="text-4xl font-black text-[#2a1f18]">Vier Säulen unserer <span className="text-[#c05a11]">Arbeit</span></h3>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {activities.map((act, i) => (
            <div key={i} className="p-8 bg-[#fcfaf7] rounded-2xl border border-stone-100 hover:border-[#4a5d23]/30 transition-all group">
              <div className="w-14 h-14 bg-[#4a5d23] text-white rounded-xl flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                {act.icon}
              </div>
              <h4 className="text-xl font-bold text-[#2a1f18] mb-3">{act.title}</h4>
              <p className="text-stone-600 text-sm leading-relaxed">{act.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
