
import React from 'react';
import { Heart, Twitter, Linkedin, Github, Mail, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#2a1f18] text-stone-300 py-24 border-t border-[#3c2a1a]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20">
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-8">
              <div className="p-2 bg-[#4a5d23] rounded-lg text-white shadow-lg">
                <Heart size={20} fill="currentColor" />
              </div>
              <span className="text-2xl font-black text-white tracking-tight">Equilibrium</span>
            </div>
            <p className="text-base leading-relaxed mb-10 font-medium opacity-80">
              Soziale Wirkung durch Stärkung lokaler Partner im globalen Süden. Gegründet 2014 in Hamburg.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-white/10 hover:text-white transition-all"><Twitter size={20} /></a>
              <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-white/10 hover:text-white transition-all"><Linkedin size={20} /></a>
              <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-white/10 hover:text-white transition-all"><Github size={20} /></a>
            </div>
          </div>
          
          <div>
            <h5 className="text-white font-black text-lg mb-8 uppercase tracking-widest border-b border-[#4a5d23] pb-2 w-fit">Aktivitäten</h5>
            <ul className="space-y-5 font-semibold">
              <li><a href="#" className="hover:text-white transition-colors">Kapazitätsaufbau</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Projektmanagement</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Personalvermittlung</a></li>
            </ul>
          </div>

          <div>
            <h5 className="text-white font-black text-lg mb-8 uppercase tracking-widest border-b border-[#4a5d23] pb-2 w-fit">Organisation</h5>
            <ul className="space-y-5 font-semibold">
              <li><a href="#" className="hover:text-white transition-colors">Über uns</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Transparenz</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Partner werden</a></li>
            </ul>
          </div>

          <div>
            <h5 className="text-white font-black text-lg mb-8 uppercase tracking-widest border-b border-[#4a5d23] pb-2 w-fit">Kontakt</h5>
            <ul className="space-y-6 font-semibold">
              <li className="flex items-center space-x-3 text-stone-300">
                <Mail size={18} className="text-[#4a5d23]" />
                <a href="mailto:info@equilibrium.foundation">info@equilibrium.foundation</a>
              </li>
              <li className="flex items-start space-x-3 text-stone-300">
                <MapPin size={18} className="text-[#4a5d23]" />
                <span>Hamburg, Deutschland</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-sm font-bold opacity-60">
          <p>&copy; {new Date().getFullYear()} Equilibrium Foundation gGmbH Hamburg.</p>
          <div className="flex space-x-8 mt-6 md:mt-0">
            <a href="#" className="hover:text-white transition-colors">Impressum</a>
            <a href="#" className="hover:text-white transition-colors">Datenschutz</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
