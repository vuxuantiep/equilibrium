
import React from 'react';
import { ArrowRight, Play, Sparkles, Globe } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section className="relative h-[90vh] flex items-center overflow-hidden bg-[#2a1f18]">
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?q=80&w=1920&auto=format&fit=crop" 
          alt="Impact in the Global South" 
          className="w-full h-full object-cover opacity-40 scale-100 transition-transform duration-10000 hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#2a1f18] via-[#2a1f18]/40 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl">
          <div className="inline-flex items-center space-x-2 bg-[#4a5d23]/30 border border-[#4a5d23]/50 px-4 py-1.5 rounded-full text-[#c7d5a0] text-sm font-bold mb-8 backdrop-blur-md">
            <Sparkles size={16} />
            <span>Handle lokal, denke global</span>
          </div>
          
          <h1 className="text-5xl md:text-8xl font-black text-white leading-tight mb-6 tracking-tight">
            Soziales <br />
            <span className="text-[#c05a11]">Gleichgewicht.</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-stone-200 mb-10 leading-relaxed font-medium max-w-2xl">
            Wir schaffen Brücken zwischen benachteiligten und privilegierten Menschen im globalen Süden. Gegründet 2014 in Hamburg, wirken wir weltweit.
          </p>
          
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
            <button className="flex items-center justify-center space-x-3 bg-[#4a5d23] hover:bg-[#3d4d1d] text-white px-10 py-5 rounded-lg font-black text-lg transition-all shadow-xl active:scale-95">
              <span>Jetzt Fördern</span>
              <ArrowRight size={22} />
            </button>
            <button className="flex items-center justify-center space-x-2 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border-2 border-white/20 px-10 py-5 rounded-lg font-black text-lg transition-all">
              <Globe size={20} className="mr-2" />
              <span>Unsere Projekte</span>
            </button>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-12 left-8 md:left-24 z-10 hidden md:block">
        <div className="flex items-center space-x-4 text-white/60 text-sm font-bold tracking-widest uppercase">
          <div className="w-12 h-[2px] bg-[#c05a11]"></div>
          <span>Hamburg, Deutschland</span>
        </div>
      </div>
    </section>
  );
};
