<?php
function equilibrium_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'main-menu' => __('Main Menu', 'equilibrium'),
        'footer-menu' => __('Footer Menu', 'equilibrium')
    ));
}
add_action('after_setup_theme', 'equilibrium_theme_setup');

function equilibrium_assets() {
    wp_enqueue_style('equilibrium-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'equilibrium_assets');
