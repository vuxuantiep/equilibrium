<?php get_header(); ?>

<main>
<section class="hero">
    <h1>Software & KI für Menschen mit Behinderung</h1>
    <p>Inklusion durch Technologie – Bildung, Software und nachhaltige Wirkung.</p>
</section>

<section class="mission">
    <h2>Mission & Werte</h2>
    <p>Wir schaffen Zugang zum Arbeitsmarkt durch digitale Bildung.</p>
</section>

<section class="projects">
    <h2>Hauptprojekte</h2>
    <ul>
        <li>Bildung für Gehörlose & Autistische Menschen</li>
        <li>Inklusive Software & KI</li>
        <li>Nachhaltigkeit & Umweltschutz</li>
    </ul>
</section>

<section class="help">
    <h2>Wie Sie helfen können</h2>
    <a href="/spenden">Spenden</a> | <a href="/engagement">Engagement</a>
</section>
</main>

<?php get_footer(); ?>
