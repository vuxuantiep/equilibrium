<?php get_header(); ?>
<main>
<h1>Blog</h1>
<?php
while (have_posts()) :
    the_post();
    the_title('<h2>', '</h2>');
    the_excerpt();
endwhile;
?>
</main>
<?php get_footer(); ?>
