<footer>
    <p>&copy; <?php echo date('Y'); ?> Equilibrium Foundation</p>
    <?php wp_nav_menu(array('theme_location' => 'footer-menu')); ?>
</footer>
<?php wp_footer(); ?>
</body>
</html>
